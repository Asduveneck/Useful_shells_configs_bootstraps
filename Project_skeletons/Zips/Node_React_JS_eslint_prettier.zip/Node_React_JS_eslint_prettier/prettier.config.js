module.exports = {
  semi: true,
  trailingComma: "all",
  singleQuote: true,
  jsxSingleQuote: true,
  tabWidth: 2,
};